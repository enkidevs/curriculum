name: AI

description: Learn how intelligent systems work, and use them to solve real-world problems.

color: a6d8ff

icon: https://img.enkipro.com/17f727781eb6d484256edff18e30eb49.png

language: Python

availableAspects:
  - introduction
  - workout

next:
  - ai:machine-learning