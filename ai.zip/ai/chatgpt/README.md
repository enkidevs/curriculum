name: ChatGPT

description: The fundamentals of R.

core: true

sections:
  '0':
    - intro-to-chatgpt
    - prompt-engineering
    - prompt-techniques
    - prompt-techniques-ii
    - chatgpt-entertainment
