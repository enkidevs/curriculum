name: ChatGPT & Entertainment

description: Playing games, generating stories, and more fun with ChatGPT!

insights:
  - using-chatgpt-for-entertainment
  - tic-tac-toe-chatgpt
  - generating-stories
  - talk-like-x-would
  - ascii-art-prompts

aspects:
  - workout