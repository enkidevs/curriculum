---
author: Stefan-Stojanovic
type: normal
category: must-know
 

---

# ASCII Art

---

## Content

---

One way to have fun with ChatGPT is to ask it to create ASCII art.

ASCII art uses a combination of characters to potray pictures or art.

Here's how we can tell ChatGPT to be an ASCII writter:

![dog-ascii](https://img.enkipro.com/929f9a0c768652b28294c35c905873bd.png)

Now it knows how to respond, so we can only send the objects name.

Here are couple more examples:
![mouse-and-cat-ascii](https://img.enkipro.com/dfdf6552936487c8125e44394fb42c95.png)

Here are "2 cats fighting":
![fighting-cats-ascii](https://img.enkipro.com/8068e4cbf37bd8997ac852a406ef65fb.png)