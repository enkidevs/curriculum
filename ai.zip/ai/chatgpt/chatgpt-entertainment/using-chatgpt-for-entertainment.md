---
author: Stefan-Stojanovic
type: normal
category: must-know
 

---

# ChatGPT Entertainment

---

## Content

---

ChatGPT can provide varius forms of entertainment including, but not limited to:
- Telling jokes
- Generating stories, poems, songs
- Generating in the style of a pirate, a famous singer, and more
- Playing games
- and so on

Let's play some games with it. We will first try a popular game like Tic Tac Toe. 

![lets-play-tic-tac-toe][https://img.enkipro.com/7b8d9cab53c5a25874ff2751b175faf2.png]