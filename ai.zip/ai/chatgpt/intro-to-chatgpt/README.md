name: Intro to ChatGPT

description: Learn how to start using ChatGPT, and the benefits it can provide.

insights:
  - what-is-chatgpt
  - why-learn-chatgpt
  - how-to-start-using-chatgpt
  - chat-vs-playground-chatgpt
  - using-chatgpt-first-time

aspects:
  - workout
  - introduction