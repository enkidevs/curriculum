---
author: Stefan-Stojanovic
type: normal
category: must-know
 

---

# Using ChatGPT 

---

## Content

---

Let's start chatting with ChatGPT!

Open the [online chat](https://chat.openai.com/chat) and let's start typing.

The first thing you will see in any chat is this:

![opening-a-chat](https://img.enkipro.com/c5c2df03f860be05760d54138d142442.png)

It gives you a short summary of its limitations and capabilities as well as some examples.

The examples are buttons you can click to copy that message to the chat and hit enter to get a response. Alternatively, you can write a prompt yourself using the chat underneath.

Here's an example prompt:
![how-are-you-chatgpt](https://img.enkipro.com/1ad6b40aae719dbe61818e4525f2056d.png)


