name: Prompt Engineering

description: Learn what prompt engineering is, what nlp is and what the structure of a good prompt contains.

insights:
  - what-is-prompt-engineering
  - what-is-a-good-prompt
  - nlp
  - first-prompts

aspects:
  - workout
  - introduction