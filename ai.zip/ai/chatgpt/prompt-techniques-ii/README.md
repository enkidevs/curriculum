name: More Prompt Techniques

description: Useful prompt techniques.

insights:
  - leveraging-tables-in-chatgpt
  - act-like-a
  - graph-outputs
  - explain-like-im-five-chatgpt
  - rewrite-my-code

aspects:
  - workout
  - deep