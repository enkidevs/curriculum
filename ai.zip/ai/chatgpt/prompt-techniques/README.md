name: Prompt Techniques

description:  Different prompting techniques to improve the performance of language models.

insights:
  - prompt-techniques
  - few-shot-prompting
  - zero-shot-prompting
  - cot-prompting

aspects:
  - workout
  - introduction
  - deep