name: Intro to ML

description: Understand how machines can learn and make decisions just like humans!

core: true

sections:
  '0':
    - welcome
    - learning-through-examples
    - learn-by-doing
    - learn-by-chasing-a-reward
    - in-practice
    - models-and-methods
    - neural-networks
