name: In Practice

description: ML techniques in practice.

insights:
  - recap-of-ml-technologies
  - semi-supervised-learning
  - selecting-data-features
  - overfitting
  
aspects:
  - introduction
  - workout
 