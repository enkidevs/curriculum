name: Learning by chasing a reward

description: Teaching the machine by rewarding the right moves.

insights:
  - what-is-reinforcement-learning
  - reinforcement-learning-example
  - reinforcement-learning-benefits
  - reinforcement-learning-challenges

aspects:
  - introduction
  - workout
 
