name: Learn by doing

description: Letting the machine figure it out itself.

insights:
  - what-is-unsupervised-learning
  - unsupervised-learning-example
  - unsupervised-learning-benefits
  - unsupervised-learning-challenges

aspects:
  - introduction
  - workout
 
