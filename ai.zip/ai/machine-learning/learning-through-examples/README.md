name: Learning through examples

description: Teaching the machine by showing it what to look for.

insights:
  - what-is-supervised-learning
  - supervised-learning-example
  - supervised-learning-benefits
  - supervised-learning-challenges
  
aspects:
  - introduction
  - workout
 
