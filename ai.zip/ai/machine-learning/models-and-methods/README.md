name: Models & Methods

description: How models make predictions and decisions.

insights:
  - decision-trees
  - ensemble-methods
  - linear-models
  
aspects:
  - introduction
  - workout
 
