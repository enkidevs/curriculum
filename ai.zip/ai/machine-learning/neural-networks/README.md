name: Neural Networks

description: The structure behind modern AI.

insights:
  - neural-networks
  - weight-vs-bias
  - simple-layers-make-complex-decisions
  - neural-network-example
  
aspects:
  - introduction
  - workout
 
