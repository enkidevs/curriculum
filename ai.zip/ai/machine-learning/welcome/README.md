name: Welcome

description: What's ML all about?

insights:
  - why-is-ml-important
  - ml-vs-ai
  - ml-is-everywhere
  - is-ml-magic
  - demystifying-the-magic
  
aspects:
  - introduction
 
