---
author: nishma
type: normal
category: discussion
practiceQuestion:
  formats:
    - fill-in-the-gap
  context: standalone
---

# Is ML magic?

---
## Content

Machine learning feels like a magic wand for computers.

It allows computers to learn and make decisions on their own.

![Machine Learning magic](https://img.enkipro.com/a411568929cb93ca2f08bed18c2cf3de.png)

But actually, it's just math and learning techniques inspired by the ways humans learn.

Let's look behind the curtain and teach you how to use the magic wand!

---
## Practice

Are you ready to peak behind the curtain and learn how ML works?

???

- I'm ready!