name: BI tools - Tableau
description: Tableau tips and best practices.
insights:
  - intro-to-tableau
  - tableau-desktop-ui
  - make-your-results-stand-out
  - dashboards-and-stories
aspects:
  - introduction