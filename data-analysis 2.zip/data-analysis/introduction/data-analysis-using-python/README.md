name: Data Analysis using Python
description: Understand the power of Python for Data Analysis.
insights:
  - intro-to-python-for-data-analysis
  - python-libraries
  - using-jupyter-notebooks
  - pandas-functions-i
  - pandas-functions-ii
aspects:
  - introduction