---
author: emmab

tags:
  - introduction

type: normal

category: must-know


---
# Marketing Analysis Tools

---
## Content

We're big advocates of using Google Analytics for understanding the effectiveness of different marketing campaigns.

But we'd like to hear from YOU!

Which are **your favorite tools** for marketing analysis? And why?

Comment below to let us know 👇.