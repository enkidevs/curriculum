name: Product Analytics
description: Metrics, methods and tools for a data-savvy Product Team.
insights:
  - intro-to-product-analytics
  - engagement
  - retention
  - a-b-testing
  - product-analytics-tools
aspects:
  - introduction