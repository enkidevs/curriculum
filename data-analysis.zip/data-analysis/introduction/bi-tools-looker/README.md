name: Looker
description: Looker tips and best practices.
insights:
  - intro-to-looker
  - how-to-use-looker
  - alerts-and-sharing
  - more-advanced-looker
aspects:
  - introduction