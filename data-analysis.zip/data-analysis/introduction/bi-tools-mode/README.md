name: Mode
description: Mode tips and best practices.
insights:
  - intro-to-mode
  - mode-for-data-analysts
  - how-to-use-mode
  - mode-customizations
aspects:
  - introduction