name: Data Analysis Buzzwords
description: Understand some of the biggest buzzwords in the data industry.
insights:
  - big-data
  - key-metrics
  - relative-vs-absolute-metrics
  - north-star-metric
aspects:
  - introduction