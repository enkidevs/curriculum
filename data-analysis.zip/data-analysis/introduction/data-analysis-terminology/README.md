name: Data Analysis Terminology
description: Understand the key mathematical and statistical concepts.
insights:
  - basic-terminology-i
  - basic-terminology-ii
  - more-terminology
aspects:
  - introduction