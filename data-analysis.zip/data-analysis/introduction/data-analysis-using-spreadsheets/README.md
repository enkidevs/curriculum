name: Data Analysis using Spreadsheets
description: Understand the power of spreadsheets for Data Analysis.
insights:
  - intro-to-spreadsheets
  - data-cleaning
  - conditional-formatting
  - sorting-and-filtering
  - pivot-tables
  - data-visualization
aspects:
  - introduction