name: Data Analysis using SQL
description: Understand the power of SQL for Data Analysis.
insights:
  - da-what-is-sql
  - syntax-i
  - syntax-ii
  - syntax-iii
  - sql-tools
aspects:
  - introduction