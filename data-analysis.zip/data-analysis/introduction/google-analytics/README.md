name: Google Analytics
description: Google Analytics tips and best practices.
insights:
  - why-google-analytics
  - how-to-use-google-analytics
  - google-analytics-user-interface
  - key-features
  - advanced-google-analytics
aspects:
  - introduction