name: Intro
description: The what, why and how of Data Analysis.
insights:
  - what-is-data-analysis
  - data-analysis-for-everyone
  - data-analysis-process
  - data-analysis-vs-data-science
aspects:
  - introduction