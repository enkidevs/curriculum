name: Marketing Analytics
description: Metrics, methods and tools for a data-savvy Marketing Team.
insights:
  - intro-to-marketing-analytics
  - marketing-metrics
  - seo-analytics
  - market-analysis
  - marketing-analytics-tools
aspects:
  - introduction