name: Sales Analytics
description: Metrics, methods and tools for a data-savvy Sales Team.
insights:
  - boost-your-performance
  - pipeline-analysis
  - other-sales-metrics
  - sales-analysis-tools
  - your-turn
aspects:
  - introduction