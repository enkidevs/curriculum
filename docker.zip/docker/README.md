name: Docker

description: Everything you wanted to know about how to containerize and deploy with Docker

color: 4FA1D0

icon: https://img.enkipro.com/84d4c9f4d92d2003359d4608d30ba8cd.png

language: bash
