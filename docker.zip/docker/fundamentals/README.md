name: Fundamentals

description: Master Docker fundamentals and demystify containers

core: true

sections:
  '0':
    - overview
    - containers
    - images
  '1':
    - storage
    - networking
