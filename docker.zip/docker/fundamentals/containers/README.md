name: containers

description: Docker's application packaging format

insights:
  - hardware-virtualization
  - docker-container-vs-vm
  - docker-containers
  - docker-container-philosophy
