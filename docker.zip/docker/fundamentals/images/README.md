name: images

description: Docker container blueprints

insights:
  - docker-images
  - dockerfile
  - docker-image-tags
  - docker-image-registries
