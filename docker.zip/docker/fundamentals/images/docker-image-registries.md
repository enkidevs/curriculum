---
author: nem035
aspects:
  - introduction
  - workout
type: normal
category: must-know
links:
- '[Docker Registry](https://docs.docker.com/registry/){documentation}'
- '[Docker Hub](https://hub.docker.com/){website}'
---

# Image Registries

---
## Content

A Docker image registry stores Docker images. We can think of a Docker image registry being to Docker images what Github is to code repositories.

By default, Docker is configured to look for images on its own registry called Docker Hub by default but users could also run their own private registry.

Docker Hub is public and allows anybody to store publicly available images.

To pull an image from DockerHub, we can use `docker pull`:

```bash
# pull a docker image named
# node from DockerHub
docker pull node
```

The command above would output something like:

```
Using default tag: latest
latest: Pulling from library/nginx
1ab2bdfe9778: Pull complete
a17e64cfe253: Pull complete
e1288088c7a8: Pull complete
Digest: sha256:53ddb41e46de3d63376579acf46f9a41a8d7de33645db47a486de9769201fec9
Status: Downloaded newer image for nginx:latest
docker.io/library/nginx:latest
```

Similarly, we can also add images to the registry by pushing them:

```bash
# push a docker image named
# enki to DockerHub
docker push enki
```

---
## Practice

Images stored on DockerHub are ???

* public
* private

---
## Revision

The default registry for Docker images is called ???

* DockerHub
* DockerStash
* DockerImages
* DockerPictures
