name: storage

description: Persisting data in the ephemeral world of containers

insights:
  - docker-intro
  - docker-volumes
  - docker-bind-mounts
  - docker-tmpfs
