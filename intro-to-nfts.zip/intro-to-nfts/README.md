name: Intro to NFTs

icon: 'https://img.enkipro.com/db79b7f9f0366f0c0e4183480a71fb91.png'

color: 'ffe0a6'

description: Fundamental Guide to NFTs for Beginners

language: python

availableAspects:
  - introduction
  - workout