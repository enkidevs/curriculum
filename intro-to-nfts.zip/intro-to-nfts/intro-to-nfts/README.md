name: Intro to NFTs

description: Fundamental Guide to NFTs for Beginners

core: true 

sections:
  '0':
    - nft-use-cases
    - fundamentals-of-nfts
    - buy-create-and-sell-nfts