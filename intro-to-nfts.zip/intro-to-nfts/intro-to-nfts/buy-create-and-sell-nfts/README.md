name: Buy, Create and Sell NFTs

description: Methods for buying, creating, and selling NFTs

insights:
  - buy-nfts
  - create-nfts
  - sell-nfts

aspects:
  - workout
