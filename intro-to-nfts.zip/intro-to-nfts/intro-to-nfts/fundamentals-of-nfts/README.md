name: Fundamentals of NFTs

description: Detailed explanation and understanding of concepts underlying NFTs

insights:
  - nf-in-nfts
  - t-in-nfts
  - how-are-nfts-valuable

aspects:
  - introduction
