name: NFT Use Cases

description: NFT ecosystem and use cases such as digital art, collectibles, and others

insights:
  - introduction
  - why-are-nfts-interesting-1
  - why-are-nfts-interesting-2
  - digital-artwork
  - nft-gaming

aspects:
  - introduction