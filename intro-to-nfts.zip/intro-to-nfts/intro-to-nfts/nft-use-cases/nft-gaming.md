---
author: nishma
type: normal
category: must-know
---
# NFT Gaming

---
## Content

NFT in gaming is the source of earning money by purchasing and trading in-game items on the cryptocurrency market. 

An example of such play-to-earn NFT game is Axie Infinity. The game rewards players with Smooth Love Potion (SLP) tokens and NFTs known as Axies. The SLP token is listed on major exchanges like Binance.

For the first time, gamers can trade their in-game rewards on the open market.

![NFT gaming](https://img.enkipro.com/89ac7ac25f429dd60e40b6c7faeb2e6d.png)

NFT games offer benefits that can't be found in traditional games: 
- you own your in-game purchases (and not the game company) 
- you can monetize and trade them on any NFT marketplace
- you don't need to fear losing the assets to duplication or bad behavior by the game maker