name: Advanced Features
description: Master complex tasks with Kotlin's powerful capabilities
core: false
next:
  - kotlin:kotlin-async-programming
sections:
  "0":
    - kotlin-extensions
    - kotlin-scope-functions
    - kotlin-destructuring
    - kotlin-recursion
    - kotlin-functional-programming
    - kotlin-generics
    - kotlin-reflection
    - kotlin-idioms-iii
    - kotlin-file-operations
    - kotlin-exception-handling
    - kotlin-packages
