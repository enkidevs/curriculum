name: Destructuring Declarations
description: Master breaking down objects into individual variables
insights:
  - kotlin-destructuring-basics
  - kotlin-destructuring-data-classes
  - kotlin-destructuring-maps-pairs
  - kotlin-destructuring-lambdas
aspects:
  - deep
  - workout 