name: Exception Handling
description: Handle errors gracefully in your code
slug: kotlin-exception-handling
aspects:
  - deep
  - workout
learnType: GROKKING
section: '0'
insights:
  - kotlin-exception-intro
  - kotlin-try-catch
  - kotlin-multiple-catch
  - kotlin-finally-block
  - kotlin-throw-exception