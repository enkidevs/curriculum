name: Kotlin Extensions
description: Enhance code with powerful, flexible extensions
insights:
  - kotlin-extension-functions
  - kotlin-extension-properties
  - kotlin-best-practices-for-extensions
aspects:
  - deep
