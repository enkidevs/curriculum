name: File Operations
description: Master file handling in Kotlin
insights:
  - kotlin-file-basics
  - kotlin-reading-writing
  - kotlin-buffered-io
  - kotlin-file-extensions
  - kotlin-error-handling
aspects:
  - deep
  - workout
