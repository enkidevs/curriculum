name: Functional Programming
description: Master functional programming concepts in Kotlin
insights:
  - kotlin-pure-functions
  - kotlin-higher-order-functions
  - kotlin-lambda-expressions
  - kotlin-function-composition
  - kotlin-immutability
aspects:
  - deep
  - workout
