name: Generics
description: Write flexible and type-safe code with generics
insights:
  - kotlin-generics-basics
  - kotlin-generic-constraints
  - kotlin-covariance
  - kotlin-contravariance
  - kotlin-generic-functions
  - kotlin-reified-generics
aspects:
  - deep
  - workout
