name: Kotlin Idioms III
description: Master advanced Kotlin idioms and patterns
insights:
  - kotlin-with-apply-idioms
  - kotlin-try-with-resources-idiom
  - kotlin-lazy-initialization-idiom
  - kotlin-destructuring-idiom
aspects:
  - deep
  - workout 