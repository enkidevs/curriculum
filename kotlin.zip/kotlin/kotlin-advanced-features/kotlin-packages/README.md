name: Packages and Imports
description: Organize and access code across files
insights:
  - kotlin-package-basics
  - kotlin-import-statements
  - kotlin-default-imports
aspects:
  - deep
  - workout 