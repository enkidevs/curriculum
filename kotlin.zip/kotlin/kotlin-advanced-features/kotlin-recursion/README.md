name: Recursion
description: Master recursive problem solving
insights:
  - kotlin-recursion-basics
  - kotlin-tail-recursion
  - kotlin-recursion-vs-iteration
  - kotlin-recursion-patterns
aspects:
  - workout
  - deep 