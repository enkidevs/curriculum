name: Reflection
description: Introspect program structure at runtime
insights:
  - kotlin-reflection-basics
  - kotlin-class-references
  - kotlin-callable-references
  - kotlin-property-references
aspects:
  - deep
  - workout 