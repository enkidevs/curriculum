name: Kotlin Extensions
description: Enhance code with powerful, flexible extensions
insights:
  - kotlin-scope-functions-apply
  - kotlin-scope-functions-let
  - kotlin-scope-functions-run
  - kotlin-scope-functions-with
  - kotlin-scope-functions-also
aspects:
  - deep
