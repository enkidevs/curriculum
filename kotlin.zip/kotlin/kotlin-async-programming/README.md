name: Async Programming
description: Effectively handle non-blocking operations
core: false
sections:
  "0":
    - kotlin-async-intro
    - kotlin-coroutines-i
    - kotlin-coroutines-ii
    - kotlin-coroutines-iii
  "1":
    - kotlin-state-flow
    - kotlin-testing-coroutines
    - kotlin-concurrency-patterns
