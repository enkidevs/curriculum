name: Concurrency Patterns
description: Master common coroutine patterns and best practices
insights:
  - kotlin-supervisor-pattern
  - kotlin-producer-consumer
  - kotlin-fan-out-fan-in
  - kotlin-select-expression
aspects:
  - deep 