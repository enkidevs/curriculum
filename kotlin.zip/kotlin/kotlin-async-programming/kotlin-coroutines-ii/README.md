name: Coroutines II
description: Master coroutine builders and job control
insights:
  - kotlin-coroutine-builders
  - kotlin-jobs-and-cancellation
  - kotlin-async-await
  - kotlin-coroutine-exception-handling
aspects:
  - deep 