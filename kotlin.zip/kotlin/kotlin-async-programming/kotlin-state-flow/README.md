name: StateFlow and SharedFlow
description: Master state management in async applications
insights:
  - kotlin-stateflow-basics
  - kotlin-sharedflow-basics
  - kotlin-flow-state-patterns
  - kotlin-hot-vs-cold-flows
aspects:
  - deep 