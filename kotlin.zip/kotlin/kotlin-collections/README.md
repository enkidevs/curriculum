name: Collections
description: Efficiently manage and process data with powerful tools
core: false
next:
  - kotlin:kotlin-advanced-features
sections:
  "0":
    - kotlin-arrays-and-lists
    - kotlin-sets-and-maps
    - kotlin-collection-operations
  "1":
    - kotlin-classes-i
    - kotlin-classes-ii
    - kotlin-classes-iii
  "2":
    - kotlin-idioms-i
    - kotlin-idioms-ii
