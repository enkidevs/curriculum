name: Arrays and Lists
description: Manage dynamic data with flexible collections
insights:
  - kotlin-arrays-fixed-size-lockers
  - kotlin-lists-expandable-shelves
  - kotlin-listof-read-only-displays
  - kotlin-real-world-to-do-lists
aspects:
  - introduction
  - workout
