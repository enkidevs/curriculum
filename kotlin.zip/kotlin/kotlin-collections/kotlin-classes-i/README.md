name: Classes and Objects 
description: Blueprint for creating data containers
insights:
- kotlin-class-basics
- kotlin-basic-properties
- kotlin-class-methods
- kotlin-custom-accessors
aspects:
- introduction
- workout
