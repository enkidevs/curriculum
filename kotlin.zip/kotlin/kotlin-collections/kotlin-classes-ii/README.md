name: Classes and Objects 
description: Blueprint for creating data containers
insights:
- kotlin-property-modifiers
- kotlin-primary-constructors
- kotlin-secondary-constructors
- kotlin-data-class-basics
- kotlin-data-class-features
- kotlin-shopping-cart-example
aspects:
- introduction
- workout
