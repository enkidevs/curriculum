name: Class Inheritance
description: Learn to extend and inherit from other classes
insights:
  - kotlin-inheritance-basics
  - kotlin-override-methods
  - kotlin-abstract-classes
  - kotlin-interfaces
  - kotlin-real-world-shapes
aspects:
  - introduction
  - workout 