name: Collection Operations
description: Manipulate and process data within collections
insights:
  - kotlin-lambda-expressions-intro
  - kotlin-add-remove-update
  - kotlin-filtering-collections
  - kotlin-looping-through-collections
  - kotlin-transforming-collections
aspects:
  - introduction
  - workout
