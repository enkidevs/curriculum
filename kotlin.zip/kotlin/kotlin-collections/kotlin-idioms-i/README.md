name: Kotlin Idioms I
description: Master essential Kotlin idioms for data and functions
insights:
  - kotlin-data-class-idiom
  - kotlin-default-parameters-idiom
  - kotlin-string-interpolation-idiom
  - kotlin-safe-null-checks-idiom
aspects:
  - introduction
  - workout 