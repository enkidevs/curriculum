name: Kotlin Idioms II
description: Master collection and functional programming idioms
insights:
  - kotlin-singleton-object-idiom
  - kotlin-when-expression-idiom
  - kotlin-collection-filtering-idiom
  - kotlin-collection-mapping-idiom
aspects:
  - introduction
  - workout 