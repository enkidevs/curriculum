name: Sets and Maps 
description: Master unique collections and key-value pairs in Kotlin 

insights:
- kotlin-sets-unique-collections
- kotlin-maps-key-value-pairs
- kotlin-mutable-vs-immutable-maps

aspects:
- introduction
- workout
