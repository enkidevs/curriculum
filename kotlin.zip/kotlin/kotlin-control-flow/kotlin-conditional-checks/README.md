name: Conditional Checks
description: Control program flow with decision-making logic
slug: kotlin-conditional-checks
aspects:
  - introduction
  - workout
learnType: GROKKING
section: '0'
insights:
  - kotlin-if-statements
  - kotlin-else-statements
  - kotlin-else-if-ladder
  - kotlin-using-conditionals-in-programs
