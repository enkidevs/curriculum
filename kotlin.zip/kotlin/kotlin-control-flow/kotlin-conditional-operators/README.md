name: Conditional Operators
description: Tools for comparing values
slug: kotlin-conditional-operators
aspects:
  - introduction
  - workout
learnType: GROKKING
section: '0'
insights:
  - kotlin-control-flow-intro
  - kotlin-comparison-operators
  - kotlin-logical-operators
