name: For Loop
description: Repeat tasks for a specific number of times
slug: kotlin-for-loop
aspects:
  - introduction
  - workout
learnType: GROKKING
section: '0'
insights:
  - kotlin-for-loop-intro
  - kotlin-for-loop-example
  - kotlin-for-loop-countdown
