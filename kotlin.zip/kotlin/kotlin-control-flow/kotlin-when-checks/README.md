name: When Checks
description: Make decisions with concise, readable code
slug: kotlin-when-checks
aspects:
  - introduction
  - workout
learnType: GROKKING
section: '0'
insights:
  - kotlin-using-when
  - kotlin-returning-when
  - kotlin-when-multiple
  - kotlin-when-vs-if-else
  - kotlin-real-world-when-checks