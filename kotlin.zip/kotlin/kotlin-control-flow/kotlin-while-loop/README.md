name: While Loop
description: Repeat tasks until a condition is met
slug: kotlin-while-loop
aspects:
  - introduction
  - workout
learnType: GROKKING
section: '0'
insights:
  - kotlin-while-loop-intro
  - kotlin-while-loop-example
  - kotlin-while-loop-real-world
