slug: kotlin-intro
name: Intro to Kotlin
description: Master the language behind Android apps
core: true
sections:
  '0':
    - kotlin-hello-world
    - kotlin-variables
    - kotlin-variable-types
    - kotlin-data-types
    - kotlin-strings
    - kotlin-arithmetic-operations
    - kotlin-functions
    - kotlin-user-input-mastery
next:
  - kotlin:kotlin-control-flow
