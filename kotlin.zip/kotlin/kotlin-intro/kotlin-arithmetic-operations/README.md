name: Arithmetic Operations
description: Master essential math skills for coding success
slug: kotlin-arithmetic-operations
aspects:
  - introduction
  - workout
learnType: GROKKING
section: '0'
insights:
  - kotlin-addition-and-subtraction
  - kotlin-multiplication-and-division
  - kotlin-modulus-operation
  - kotlin-order-of-operations
  - kotlin-arithmetic-in-programs
