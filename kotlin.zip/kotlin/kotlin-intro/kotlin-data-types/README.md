name: Data Types
description: Master essential data types for versatile programming
slug: kotlin-data-types
aspects:
  - introduction
  - workout
learnType: GROKKING
section: '0'
insights:
  - kotlin-int-data-type
  - kotlin-string-data-type
  - kotlin-boolean-data-type
  - kotlin-type-inference
  - kotlin-type-conversion
