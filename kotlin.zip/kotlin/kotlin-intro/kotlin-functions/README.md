name: Functions
description: Write reusable code blocks to solve complex problems
slug: kotlin-functions
aspects:
  - introduction
  - workout
learnType: GROKKING
section: '0'
insights:
  - kotlin-defining-functions
  - kotlin-calling-functions
  - kotlin-function-parameters
  - kotlin-return-values
  - kotlin-return-types
  - kotlin-real-world-function
  - kotlin-function-scope
