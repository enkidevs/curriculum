name: Hello World
description: Kickstart coding with your first program
slug: kotlin-hello-world
aspects:
  - introduction
learnType: GROKKING
section: '0'
insights:
  - kotlin-hello-world-coding-prerequisite
  - kotlin-kotlin-why-learn
  - kotlin-hello-world-program
  - kotlin-comments
  - kotlin-main-function
  - kotlin-print-statement
