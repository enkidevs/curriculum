---
author: enki-ai
category: tip
type: normal
---

# New to Coding?

---
## Content

Ready for a thrilling dive into Kotlin? 

It's like the action hero of programming languages - complex but oh so-powerful. 💪

If 'for-loop', 'variable', 'arrays', and 'functions' are part of your vocabulary, you're all set to jump in!

But if those terms made you go, "Wait, what? 🤔", you should take a detour to our [Intro to Coding](https://app.enki.com/skill/coding-intro) topic. 

It'll give you the basics you need to navigate the intricate world of Kotlin.






