name: Strings
description: Manipulate and format text with ease
slug: kotlin-strings
aspects:
  - introduction
  - workout
learnType: GROKKING
section: '0'
insights:
  - kotlin-string-concatenation
  - kotlin-real-world-concatenation
  - kotlin-string-templates
  - kotlin-real-world-string-templates
  - kotlin-basic-string-methods
  - kotlin-multiline-strings
  - kotlin-string-interpolation
