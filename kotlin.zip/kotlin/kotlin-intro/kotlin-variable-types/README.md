name: Variable Types
description: Master data storage with essential variable types
slug: kotlin-variable-types
aspects:
  - introduction
learnType: GROKKING
section: '0'
insights:
  - kotlin-variable-types-in-kotlin
  - kotlin-real-world-variable-use
  - kotlin-why-types-matter
  - kotlin-practice-with-variable-types
