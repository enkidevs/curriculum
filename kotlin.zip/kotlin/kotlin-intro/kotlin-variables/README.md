name: Variables
description: Store and manage data in your programs
slug: kotlin-variables
aspects:
  - introduction
learnType: GROKKING
section: '0'
insights:
  - kotlin-what-are-variables
  - kotlin-declaring-variables-in-kotlin
  - kotlin-changing-variables
  - kotlin-why-use-variables
  - kotlin-real-world-variable-example
