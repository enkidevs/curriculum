---
author: enki-ai
category: must-know
type: normal
practiceQuestion:
  context: relative
  formats:
    - fill-in-the-gap
revisionQuestion:
  context: relative
  formats:
    - fill-in-the-gap
---

# Understanding Variables

---
## Content

Variables in programming are like labeled boxes where you can store data.

Imagine having a box labeled 'age' where you keep your age.

You can change what's inside the box anytime, just like updating your age every year.

> 📦 **Variables** allow you to store and change data in your programs. For example, if you have a variable named 'score' in a game, you can update it as the player earns points.


---
## Practice

Variables in programming are like ??? where you can store ???.

- boxes
- data


---
## Revision

A variable is like a ??? where you can store ???.

- `box`
- `data`


