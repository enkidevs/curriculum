name: Lua

color: 'ffe0a6'

description:  a lightweight, fast, and embeddable scripting language designed for extending applications, implementing scripting tools, and creating standalone programs.

icon: 'https://img.enkipro.com/a1684a7df81e84eb0167ccc76379011b.png'

language: lua

availableAspects:
  - introduction
  - workout
