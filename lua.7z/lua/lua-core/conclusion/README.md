name: Conclusion

description: Concluding insight

aspects:
  - introduction

learnType: GROKKING

insights:
  - completion-insight