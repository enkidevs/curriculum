name: Conditional Statements I

description: Learn about conditional statements.

aspects:
  - introduction
  - workout

learnType: GROKKING

insights:
  - what-are-conditional-statements-lua
  - if-in-lua-i
  - if-in-lua-ii