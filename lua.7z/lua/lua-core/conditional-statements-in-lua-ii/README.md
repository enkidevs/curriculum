name: Conditional Statements II

description: Learn about additional conditional statements.

aspects:
  - introduction
  - workout

learnType: GROKKING

insights:
  - if-else-in-lua-i
  - if-else-in-lua-ii
  - if-elseif-else-in-lua-i
  - if-elseif-else-in-lua-ii