name: Functions

description: Learn how to Create and Call Functions in Lua.

aspects:
  - introduction
  - workout

learnType: GROKKING

insights:
  - functions-in-lua-i
  - functions-in-lua-ii
  - functions-in-lua-iii
  - functions-in-lua-iv