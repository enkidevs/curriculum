name: Local Variables

description: Learn about Local Variables.

aspects:
  - introduction
  - workout

learnType: GROKKING

insights:
  - local-variables-in-lua-i
  - local-variables-in-lua-ii