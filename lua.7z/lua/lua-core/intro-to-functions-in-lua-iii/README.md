name: Functions with Variables & Vararg

description: Learn how to Assign Functions to Variables and Vararg Expression.

aspects:
  - introduction
  - workout

learnType: GROKKING

insights:

  - assigning-functions-to-variables-in-lua-i
  - assigning-functions-to-variables-in-lua-ii
  - vararg-expression-in-lua-i
  - vararg-expression-in-lua-ii