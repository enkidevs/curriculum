name: Installing Lua 

description: Learn how to Install Lua!

aspects:
  - introduction

learnType: GROKKING

insights:
  - installing-lua-i
  - installing-lua-ii
  - installing-lua-iii