name: I/O Operations I

description: Learn about the IO library and how to read and write to files.

aspects:
  - introduction
  - workout

learnType: GROKKING

insights:
  - the-io-library-in-lua
  - io-write-in-lua-i
  - io-write-in-lua-ii
  - io-read-in-lua-i
  - io-read-in-lua-ii