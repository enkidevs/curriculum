name: Lua in Games

description: Learn how Lua is used in various video games!

aspects:
  - introduction
  - workout

learnType: GROKKING

insights:
  - lua-in-games-i
  - lua-in-games-ii
  - lua-in-games-iii