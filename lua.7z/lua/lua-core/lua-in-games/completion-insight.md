---
author: Stefan-Stojanovic
category: discussion
type: normal
---

# Conclusion

---

## Content

Congratulations! 🎉🎉🎉

You have completed the basics of Lua Coding! 

If you're interested, you could also try out our **Roblox course**, where we teach you how to build simple games using Roblox's game-developing studio and Lua code.

>💬 Now that you have a solid grasp of the Lua language, what are your plans now?
>
> Leave a comment or view some of the other comments for inspiration.

