name: Arithmetic Operators

description: Learn about Arithmetic Operators in Lua.

aspects:
  - introduction
  - workout

learnType: GROKKING

insights:
  - arithmetic-operators-in-lua-i
  - arithmetic-operators-in-lua-ii
  - arithmetic-operators-in-lua-iii