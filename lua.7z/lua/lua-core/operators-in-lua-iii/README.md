name: Relational Operators

description: Learn about Relational Operators in Lua

aspects:
  - introduction
  - workout

learnType: GROKKING

insights:
  - relational-operators-in-lua-i
  - relational-operators-in-lua-ii
  - relational-operators-in-lua-iii