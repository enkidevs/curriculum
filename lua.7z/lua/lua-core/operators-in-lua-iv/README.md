name: Length and Concatenation Operators

description: Learn about Length and Concatenation Operators in Lua.

aspects:
  - introduction
  - workout

learnType: GROKKING

insights:
  - length-operators-in-lua-i
  - length-operators-in-lua-ii
  - concatenation-operator-in-lua