name: Tables I

description: Tables are a fundamental data structure used to represent arrays, lists, sets, and more!

aspects:
  - introduction
  - workout

learnType: GROKKING

insights:
  - more-data-types-in-lua
  - tables-in-lua
  - arrays-in-lua-i
  - arrays-in-lua-ii
  - arrays-in-lua-iii

