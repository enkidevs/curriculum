name: Variables & Data types I

description: Learn how to create variables.

aspects:
  - introduction
  - workout

learnType: GROKKING

insights:
  - variables-in-lua-i
  - variables-in-lua-ii
  - variables-in-lua-iii
  