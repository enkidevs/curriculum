name: Basic Modelling I

description: Learn the basics of modelling!

aspects:
- introduction

insights:
- adding-objects
- moving-objects
- scaling-objects
- rotating-objects


