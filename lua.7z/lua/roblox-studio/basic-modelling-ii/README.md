name: Basic Modelling II

description: Learn About Extra Tools Used in Modelling!

aspects:
- introduction

insights:
- useful-properties-i
- useful-properties-ii
- useful-properties-iii
- external-tools-i
- external-tools-ii

