name: Building Obstacles II

description: Use this course's content to build simple obstacles!

aspects:
- workout

insights:
- applying-multiple-scripts-i
- applying-multiple-scripts-ii
- themes-creativity