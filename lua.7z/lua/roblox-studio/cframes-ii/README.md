name: CFrame Basics II

description: Learn the basics of CFrame!

aspects:
- workout

insights:

- cframes-math-i
- cframes-math-ii
- cframes-application-i
- cframes-application-ii

