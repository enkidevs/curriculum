name: Properties II

description: Learn how to adjust properties through code!

aspects:
- workout

insights:
- color-i
- color-ii
- cast-shadow
- material
- reflect-and-transparent