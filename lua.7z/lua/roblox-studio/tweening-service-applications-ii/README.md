name: TweenService Applications II

description: Learn how to use animations with TweenService!

aspects:
- workout

insights:
- multiple-tweens-i
- multiple-tweens-ii
- multiple-tweens-iii

