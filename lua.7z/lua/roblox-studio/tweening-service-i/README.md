name: TweeningService I

description: Learn how to use TweenService in Roblox Studio!

aspects:
- workout

insights:
- tween-service-intro-i
- tween-service-intro-ii
- tween-service-syntax
- property-table-variable
- info-variable


