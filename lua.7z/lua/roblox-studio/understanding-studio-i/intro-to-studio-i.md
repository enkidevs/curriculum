---
author: junoocha
type: normal
category: discussion


---

# Welcome To Roblox Studio

---

## Content
Roblox, the hub of imagination, where you can create anything you wish. You excitedly hop onto Roblox Studio[1] to create the game of your dreams and… oh. How do I start? 

---

## Footnotes

[1: Roblox Studio]

Roblox Studio is the application where you’re able to create your own game. This is a separate application from the Roblox app.
