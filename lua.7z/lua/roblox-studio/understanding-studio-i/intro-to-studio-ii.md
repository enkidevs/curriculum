---
author: junoocha
type: normal
category: discussion


---

# What to Expect

---

## Content

Throughout this course, we will be walk you through how Roblox Studio works and how you can start coding and building your own Roblox game. By the end of this course, you should be able to create a simple obstacle course, AKA obbys[1] on Roblox.

---

## Footnotes

[1: Obby]

Obbys are short for Obstacle Courses, and is commonly used on the Roblox platform.
