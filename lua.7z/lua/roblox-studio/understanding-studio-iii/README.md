name: Property Interface

description: Learn about the basics of the Property Interface!

aspects:
- workout

insights:
- properties-interface-i
- properties-interface-ii
- properties-interface-iii


