name: Vector3 Basics I

description: Learn the basics of Vector3!

aspects:
- workout

insights:
- vector3-intro
- vector3-syntax-i
- vector3-syntax-ii
- vector3-syntax-iii

