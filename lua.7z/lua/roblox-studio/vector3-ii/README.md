name: Vector3 Basics II

description: Learn the basics of Vector3's math applications!

aspects:
- workout

insights:
- add-subtract
- multiply-divide-i
- multiply-divide-ii

