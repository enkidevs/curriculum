name: Lua

icon: 'https://img.enkipro.com/a1684a7df81e84eb0167ccc76379011b.png'

color: 'ffe0a6'

description:  a lightweight, fast, and embeddable scripting language designed for extending applications, implementing scripting tools, and creating standalone programs.

language: python

availableAspects:
  - introduction
  - workout
