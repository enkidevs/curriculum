name: Lua

color: a6ceff

description: Build games, desktop apps, and script robots.

icon: 'https://img.enkipro.com/a1684a7df81e84eb0167ccc76379011b.png'

language: lua

availableAspects:
  - introduction
  - workout
 
