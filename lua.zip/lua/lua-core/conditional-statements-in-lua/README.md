name: Conditional Statements

description: Learn about conditional statements.

aspects:
  - introduction
  - workout

learnType: GROKKING

insights:
  - what-are-conditional-statements-lua
  - if-in-lua
  - if-else-in-lua
  - if-elseif-else-in-lua