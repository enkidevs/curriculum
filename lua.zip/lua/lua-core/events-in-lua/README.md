name: Events in Lua

description: Learn how to use events in Lua!

aspects:
  - introduction

learnType: GROKKING

insights:
  - simple-event-example-in-lua-i
  - simple-event-example-in-lua-ii
  - advanced-event-example-in-lua
  - completion-insight