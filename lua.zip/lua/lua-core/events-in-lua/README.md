name: Events

description: Learn what events are and how to use them.

aspects:
  - introduction

learnType: GROKKING

insights:
  - what-are-events-in-lua
  - flexible-event-system-in-lua
  - simple-event-example-in-lua
  - advanced-event-example-in-lua