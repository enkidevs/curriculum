---
author: Stefan-Stojanovic
category: discussion
type: normal
---

# Conclusion

---

## Content

Congratulations! 🎉🎉🎉

You have completed the basics for Lua Coding! 

If you're interested, the next few insights go through the usage of Lua in WoW. These insights **can provide a better idea of how Lua is used in games**!

If perhaps WoW is not your cup of tea, you could also try out our Roblox course, where we teach you how to build simple games using Roblox's game developing studio.

>💬 Now that you have a solid grasp of the Lua language, what are your plans now?
>
> Leave a comment or view some of the other comments for inspiration before moving on.

