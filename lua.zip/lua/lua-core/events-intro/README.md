name: Events Intro

description: Learn what events are.

aspects:
  - introduction

learnType: GROKKING

insights:
  - what-are-events-in-lua-i
  - what-are-events-in-lua-ii
  - flexible-event-system-in-lua
