---
author: Stefan-Stojanovic
category: must-know
type: normal
---

# What are Events? I

---
## Content

In Lua, an **event** is a **signal that something has occurred**, such as a button being clicked or a key being pressed. 

