name: Functions

description: Learn how to create functions, how to assign them to variables, and more.

aspects:
  - introduction
  - workout

learnType: GROKKING

insights:
  - functions-in-lua
  - functions-in-lua-ii
  - local-variables-in-lua
  - assigning-functions-to-variables-in-lua
  - vararg-expression-in-lua