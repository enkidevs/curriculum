---
author: Stefan-Stojanovic
category: must-know
type: normal
---

# What Is Lua?

---
## Content

Lua is a **lightweight, fast, and versatile** programming language. It was created in Brazil in 1993 and is currently maintained by a team of developers at PUC-Rio, the Pontifical Catholic University of Rio de Janeiro.
