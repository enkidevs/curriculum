name: Getting Started with Lua

description: Learn how to get Started with Lua!

aspects:
  - introduction

learnType: GROKKING

insights:
  - install
  - text-editor
  - practicing
  - community