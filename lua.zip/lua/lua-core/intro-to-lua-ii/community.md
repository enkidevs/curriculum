---
author: Stefan-Stojanovic
category: must-know
type: normal


---

# Joining the Lua Community

---

## Content

Lua has a **friendly and supportive community** of users and developers. 

Joining a Lua forum or mailing list can be a great way to get help when you need it and to connect with other Lua programmers.
