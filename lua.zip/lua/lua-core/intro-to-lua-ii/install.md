---
author: Stefan-Stojanovic
category: must-know
type: normal


---

# Installing the Interpreter

---
## Content

Before you can start coding in Lua, you need to **install the Lua interpreter** on your computer. You can download the Lua interpreter from the official Lua website.

> The next workout will specify the steps needed to install the interpreter.

