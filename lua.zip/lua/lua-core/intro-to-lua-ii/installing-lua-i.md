---
author: Stefan-Stojanovic
category: must-know
type: normal


---

# Installing the Interpreter I

---
## Content

Now hold your horses! Before you can start coding in Lua, you need to install a **Lua interpreter** and a **text editor** on your computer. After all, you may want to save projects and code to edit later!

For the interpreter, you can easily find it on the download page of the [official Lua website](https://www.lua.org/download.html).

![lua-page](https://img.enkipro.com/64a0a79caa1509f92a7914b77d97f1b3.png)