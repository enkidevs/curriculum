---
author: Stefan-Stojanovic
category: must-know
type: normal


---

# Choosing a Lua Text Editor

---
## Content

To write your Lua code, you **need a text editor**. 

There are many options to choose from, including **Sublime Text**, **Atom**, **Notepad++**, **VSCode** and more. You can find their installation pages through Google.

> Consider which text editorChoose the one that you're most comfortable with.
