name: Installing Lua

description: Learn how to Install Lua!

aspects:
  - introduction

learnType: GROKKING

insights:
  - installing-i
  - installing-ii
  - installing-iii
  - alternative