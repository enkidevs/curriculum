---
author: nemanjaenki
category: must-know
type: normal


---

# Lua Alternative

---

## Content

If you do not want to install the interpreter, you can use their website IDE[1] to test some code or view their demo programs: [live demo](https://www.lua.org/demo.html).

---

## Footnotes

[1: IDE]

Stands for integrated development environment. It creates an environment developing code.