---
author: nemanjaenki
category: must-know
type: normal

---

# Installing Lua I

---

## Content

The first step is to **download the Lua interpreter**, which is available for Windows, macOS, and Linux. 

You can download the latest version of the interpreter from the [official Lua website](https://www.lua.org/download.html).

