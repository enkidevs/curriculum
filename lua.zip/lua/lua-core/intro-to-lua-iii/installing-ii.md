---
author: nemanjaenki
category: must-know
type: normal


---

# Installing Lua II

---

## Content

Once you've downloaded the Lua interpreter, you'll need to **install the interpreter on your computer**. 

The installation process will vary depending on your operating system.

