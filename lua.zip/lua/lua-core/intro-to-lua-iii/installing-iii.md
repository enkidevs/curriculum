---
author: nemanjaenki
category: must-know
type: normal


---

# Installing Lua III

---

## Content

After you've installed the Lua interpreter, you should test that the interpreter works. 

You can test it by **running the** `lua` **command in your terminal or command prompt**. If Lua is installed correctly, you should see the **Lua prompt (>) appear**. 

You can then enter Lua code and see it executed.


