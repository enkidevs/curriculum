name: Your First Lua Program

description: Learn how to Create your First Program!

aspects:
  - introduction

learnType: GROKKING

insights:
  - hello-world-in-lua-i
  - hello-world-in-lua-ii
  - hello-world-in-lua-iii
