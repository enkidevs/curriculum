---
author: nemanjaenki
category: must-know
type: normal

---

# Hello World I

---
## Content

Like with every other language, let's write our first hello world program!

```lua
print("Hello, world!")
-- Hello, world!
```

When you run this code, you should find the words, "Hello world!" in the terminal[1].



