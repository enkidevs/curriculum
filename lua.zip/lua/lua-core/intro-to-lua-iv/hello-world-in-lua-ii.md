---
author: nemanjaenki
category: must-know
type: normal

---

# Hello World II

---

## Content

```lua
print("Hello, world!")
-- Hello, world!
```

The `--` is used to denote a single line comment. Which we will use to showcase outputs of programs.




