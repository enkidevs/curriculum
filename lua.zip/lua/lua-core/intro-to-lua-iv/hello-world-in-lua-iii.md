---
author: nemanjaenki
category: must-know
type: normal
practiceQuestion:
  formats:
    - fill-in-the-gap
  context: standalone

---

# Hello World

---
## Content

```lua
print("Hello, world!")
-- Hello, world!
```

The `print("Hello, world!")` is used to print the "Hello, world!" in the terminal.


---
## Practice

Finish the code to output a greetings message:

```lua
???("Hello, world!")
```

- print
- output
- write


