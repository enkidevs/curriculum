name: Intro to Lua 

description: Learn what Lua Language is!

aspects:
  - introduction

learnType: GROKKING

insights:
  - what-is-lua
  - why-learn-lua
  - intro-code-lua
  - what-to-expect