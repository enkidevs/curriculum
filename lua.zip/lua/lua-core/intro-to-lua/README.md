name: Intro to Lua

description: Learn what Lua is, and how to create your first Hello world program!

aspects:
  - introduction

learnType: GROKKING

insights:
  - lua-intro
  - getting-started-with-lua
  - installing-lua
  - hello-world-in-lua