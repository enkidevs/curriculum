---
author: nemanjaenki
category: must-know
type: normal
practiceQuestion:
  formats:
    - fill-in-the-gap
  context: standalone

---

# Hello World

---
## Content

Like with every other language, let's write our first hello world program!

```lua
print("Hello, world!")
-- Hello, world!
```

The `--` is used to denote a single line comment. Which we will use to showcase outputs of programs.


---
## Practice

Finish the code to output a greetings message:

```lua
???("Hello, world!")
```

- print
- output
- write


