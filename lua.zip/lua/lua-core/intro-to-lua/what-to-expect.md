---
author: Stefan-Stojanovic
category: must-know
type: normal
---

# What to Expect?

---
## Content

Congratulations on practicing with your first few lines of Lua! Sure, it may have been a simple hello statement, but **you've made progress!**

This may seem underwhelming at first, but Lua can lead to very complicated ideas and logic! 

Later in the Lua section, you will learn about how you can apply Lua to World of Warcraft! If you're really interested, there's also a Roblox Lua course that explores various functions! 

Here's a small project taught in the Roblox course:

> Waiting on gif implementation