name: I/O Operations

description: Learn about the IO library and how to open, read and write to files.

aspects:
  - introduction
  - workout

learnType: GROKKING

insights:
  - the-io-library-in-lua
  - io-write-in-lua
  - io-read-in-lua
  - io-lines-in-lua
  - io-open-in-lua
  - io-input-output-in-lua