name: Loops Introduction

description: Learn about what loops are in Lua.

aspects:
  - introduction

learnType: GROKKING

insights:
  - what-are-loops-in-lua
  - for-and-while-loops
  - repeat-loops
  - why-use-loops