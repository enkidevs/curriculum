---
author: Stefan-Stojanovic
category: must-know
type: normal

---

# Why use Loops?

---
## Content

Loops are essential for controlling program flow and performing tasks efficiently. By understanding the different types of loops in Lua and when to use them, you *can write more effective code* and *solve problems more efficiently* **while writing less code**.



