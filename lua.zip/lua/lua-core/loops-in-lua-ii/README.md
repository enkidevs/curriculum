name: For and While Loops

description: Learn more about For and While Loops in Lua.

aspects:
  - introduction

learnType: GROKKING

insights:
  - for-loops-in-lua-i
  - for-loops-in-lua-ii
  - while-loops-in-lua-i
  - while-loops-in-lua-ii
