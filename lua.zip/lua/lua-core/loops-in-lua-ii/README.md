name: For and While Loops

description: Learn more about Repeat and While Loops in Lua.

aspects:
  - introduction

learnType: GROKKING

insights:
  - while-loops-in-lua-i
  - while-loops-in-lua-ii
  - repeat-loops-in-lua-i
  - repeat-loops-in-lua-ii
