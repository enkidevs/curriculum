name: repeat Loops

description: Learn about repeat Loops in Lua.

aspects:
  - introduction

learnType: GROKKING

insights:
  - repeat-loops-in-lua-i
  - repeat-loops-in-lua-ii
  - repeat-loops-in-lua-iii
  - repeat-loops-in-lua-iv