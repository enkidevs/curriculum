name: Loops

description: Learn about the different types of loops Lua offers.

aspects:
  - introduction

learnType: GROKKING

insights:
  - what-are-loops-in-lua
  - for-loops-in-lua
  - while-loops-in-lua
  - repeat-loops-in-lua
  - more-on-repeat-loops-in-lua