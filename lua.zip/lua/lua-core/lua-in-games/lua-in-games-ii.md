---
author: Stefan-Stojanovic
category: must-know
type: normal


---

# Lua in WoW

---

## Content

One example of the usefulness of Lua in a game can be seen in the **popular game World of Warcraft (WoW)**. Lua scripts are used extensively in World of Warcraft to **allow players to customize** their user interface, automate tasks, and create add-ons to enhance their gameplay experience.

Not only can developers use Lua to create games, but **players can write such scripts to tailor their game experience** to their preferences, making it more enjoyable and efficient!

