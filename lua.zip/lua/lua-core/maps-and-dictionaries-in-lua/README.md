name: Maps / Dictionaries

description: Learn how to create Maps/Dictionaries using tables in Lua.

aspects:
  - introduction
  - workout

learnType: GROKKING

insights:
  - maps-or-dictionaries-in-lua-i
  - maps-or-dictionaries-in-lua-ii
  - map-methods-in-lua-i
  - map-methods-in-lua-ii
  - map-methods-in-lua-iii