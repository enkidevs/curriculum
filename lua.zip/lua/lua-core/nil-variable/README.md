name: The Nil Variable

description: Learn about the Nil Variable and it's Uses.

aspects:
  - introduction
  - workout

learnType: GROKKING

insights:
  - nil-in-lua
  - resetting-a-variable
  - releasing-memory
