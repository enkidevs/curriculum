name: Logical Operators

description: Learn about what Operators are and Logical Operators in Lua.

aspects:
  - introduction
  - workout

learnType: GROKKING

insights:
  - what-are-operators-in-lua
  - logical-operators-in-lua-i
  - logical-operators-in-lua-ii
  - logical-operators-in-lua-iii
  - logical-operators-in-lua-iv