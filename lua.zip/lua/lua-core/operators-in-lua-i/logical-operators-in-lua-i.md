---
author: Stefan-Stojanovic
category: must-know
type: normal


---

# Logical Operators

---

## Content

Logical operators are used to perform logical operations on boolean values. The three logical operators are `and`, `or`, and `not`.