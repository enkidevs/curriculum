name: Operators

description: Logical, arithmetic, relational and other operators in Lua.

aspects:
  - introduction
  - workout

learnType: GROKKING

insights:
  - what-are-operators-in-lua
  - arithmetic-operators-in-lua
  - logical-operators-in-lua
  - relational-operators-in-lua
  - length-operators-in-lua
  - concatenation-operator-in-lua