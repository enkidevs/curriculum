name: Display Gold Addon I

description: Let's create an addon that displays our gold, silver and copper on the screen!

aspects:
  - introduction
  - workout

learnType: GROKKING

insights:
  - toc-file-i
  - toc-file-ii
