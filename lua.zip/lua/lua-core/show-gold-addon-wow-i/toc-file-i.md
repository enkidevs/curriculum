---
author: Stefan-Stojanovic
category: must-know
type: normal

---

# Show Gold Toc File I

---
## Content

In the base game, in order to see your gold, silver and copper, you would have to open your backpack.

Let's create a Lua script that displays the player's current gold on the screen.

First thing, open your AddOns folder and create a new folder called "ShowGold".
Inside it, create 2 files:
- ShowGold.lua
- ShowGold.toc