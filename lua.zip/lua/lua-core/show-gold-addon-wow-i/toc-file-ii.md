---
author: Stefan-Stojanovic
category: must-know
type: normal

---

# Show Gold Toc File II

---
## Content

Inside the `.toc` file, we will add this:
```plain-text
## Interface: 100005
## Title: Show Gold
## Notes: Continuously Show Gold on screen
## Author: Your Name
## Version: 0.0.1

ShowGold.lua
```

You can save and close this file. Let's continue onto the Lua code in the next workout.