---
author: Stefan-Stojanovic
category: must-know
type: normal

---

# Show Gold Addon V

---
## Content

This script creates a new frame on the screen and adds a font string to display the player's current gold. The script then sets up an event listener that updates the gold text whenever the player's money changes.

Here's how that looks in game:

![show-money-no-ui](https://img.enkipro.com/6d6526066cd148fd4026ea9a2965ae53.png)