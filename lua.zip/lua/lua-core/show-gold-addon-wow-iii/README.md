name: Display Gold Addon III

description: Let's create an addon that displays our gold, silver and copper on the screen!

aspects:
  - introduction
  - workout

learnType: GROKKING

insights:
  - modifying-background-i
  - modifying-background-ii
  - modifying-background-iii
  - changing-position
