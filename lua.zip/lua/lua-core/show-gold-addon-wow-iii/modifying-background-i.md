---
author: Stefan-Stojanovic
category: must-know
type: normal

---

# Modifying Background of Gold Addon I

---
## Content

Previously we have created an addon that looks like this:

![show-money-no-ui](https://img.enkipro.com/6d6526066cd148fd4026ea9a2965ae53.png)

Note that If you have no Gold, it might look like this:

![show-silver-copper](https://img.enkipro.com/ab3a22955103848bf43682b6c668b333.png)

Or if you only have copper, like this:

![show-copper](https://img.enkipro.com/686e79fccf24dcb41a8b04147bc9c5d4.png)

This function determines your money and only displays the value if you have it.

Now let's modify the background texture.

