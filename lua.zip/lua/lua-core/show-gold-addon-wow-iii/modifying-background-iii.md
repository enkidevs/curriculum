---
author: Stefan-Stojanovic
category: must-know
type: normal

---

# Modifying Background of Gold Addon III

---
## Content

The result is a visually distinct background for the frame that helps to make it stand out from other UI elements.

Which looks like this:

![bg-frame](https://img.enkipro.com/f811983c76bbd2178525b70fc4142633.png)
