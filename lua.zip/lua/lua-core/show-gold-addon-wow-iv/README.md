name: Display Gold Addon IV

description: Let's create an addon that displays our gold, silver and copper on the screen!

aspects:
  - introduction
  - workout

learnType: GROKKING

insights:
  - continously-update-gold-i
  - continously-update-gold-ii
  - continously-update-gold-iii
  - continously-update-gold-iv
  - full-show-gold-addon-code
