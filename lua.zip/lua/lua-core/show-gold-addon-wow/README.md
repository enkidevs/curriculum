name: Display Gold Addon

description: Let's create an addon that displays our gold, silver and copper on the screen!

aspects:
  - introduction
  - workout

learnType: GROKKING

insights:
  - show-gold-addon-wow
  - show-gold-addon-wow-ii
  - show-gold-addon-wow-iii
  - show-gold-addon-wow-iv
  - show-gold-addon-wow-v
  - full-show-gold-addon-code