name: Tables II

description: Tables are a fundamental data structure used to represent arrays, lists, sets, and more!

aspects:
  - introduction
  - workout

learnType: GROKKING

insights:
  - nested-tables
  - matrices-in-lua-i
  - matrices-in-lua-ii
  - matrices-in-lua-iii
  - matrices-in-lua-iv