name: More on Tables

description: Learn how to store and assign functions to a table.

aspects:
  - introduction
  - workout

learnType: GROKKING

insights:
  - sets-in-lua
  - tables-can-store-functions-in-lua
  - assigning-functions-to-existing-tables-in-lua