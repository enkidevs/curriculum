name: More on Tables I

description: Learn how to store and assign functions to a table.

aspects:
  - introduction
  - workout

learnType: GROKKING

insights:
  - sets-in-lua-i
  - sets-in-lua-ii
  - sets-in-lua-iii