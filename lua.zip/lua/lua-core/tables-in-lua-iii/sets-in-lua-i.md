---
author: Stefan-Stojanovic
category: must-know
type: normal

---

# Sets Introduction

---

## Content

A **set** is a **collection of values that contains no duplicates**. 

A set is not a built-in data structure in Lua, but it can be implemented using tables.

