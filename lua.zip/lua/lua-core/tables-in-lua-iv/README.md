name: More on Tables II

description: Learn how to store and assign functions to a table.

aspects:
  - introduction
  - workout

learnType: GROKKING

insights:
  - tables-can-store-functions-in-lua-i
  - tables-can-store-functions-in-lua-ii
  - assigning-functions-to-existing-tables-in-lua-i
  - assigning-functions-to-existing-tables-in-lua-ii