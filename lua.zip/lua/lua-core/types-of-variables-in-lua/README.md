name: Variables & Data types II

description: Learn how to create variables and what data types Lua offers.

aspects:
  - introduction
  - workout

learnType: GROKKING

insights:
  - different-types-of-variables
  - numbers-in-lua
  - booleans-in-lua
  - strings-in-lua