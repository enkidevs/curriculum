name: Variables & Data types

description: Learn how to create variables and what data types Lua offers.

aspects:
  - introduction
  - workout

learnType: GROKKING

insights:
  - what-are-variables-in-lua
  - different-types-of-variables-in-lua
  - numbers-in-lua
  - booleans-in-lua
  - strings-in-lua
  - nil-in-lua