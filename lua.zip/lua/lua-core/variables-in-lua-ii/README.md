name: Variables & Data types II

description: Learn what data types Lua offers.

aspects:
  - introduction
  - workout

learnType: GROKKING

insights:
  - data-types-in-lua
  - strings-in-lua
  - numbers-in-lua
  - booleans-in-lua