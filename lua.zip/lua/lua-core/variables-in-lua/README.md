name: Variables & Data types

description: Learn how to create variables and what data types Lua offers.

aspects:
  - introduction
  - workout

learnType: GROKKING

insights:
  - variables-in-lua-i
  - variables-in-lua-ii
  - variables-in-lua-iii