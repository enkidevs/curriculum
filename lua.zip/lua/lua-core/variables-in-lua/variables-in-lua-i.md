---
author: nemanjaenki
category: must-know
type: normal
practiceQuestion:
  formats:
    - fill-in-the-gap
  context: standalone
revisionQuestion:
  formats:
    - fill-in-the-gap
  context: standalone

---

# What are Variables in Lua?

---

## Content

In Lua, a variable is a **named storage location** in the computer's memory that **holds a value**.

Values can be a number, a word, or a more complex data structure. 

---

## Practice

A variable is... ???

- A named storage location
- A comment
- An equation
- A storage location

---

## Revision

A variable is a named storage location that... ??? 

- Holds a value
- Holds only strings
- Holds only numbers
- Holds a statement