name: WoW Addons I

description: Learn how to create simple addons in WoW to enhance your experience.

aspects:
  - introduction
  - workout

learnType: GROKKING

insights:
  - before-making-an-addon-in-wow-in-lua
  - hello-world-in-wow-i
  - hello-world-in-wow-ii
  - hello-world-in-wow-iii