---
author: Stefan-Stojanovic
category: must-know
type: normal


---

# Hello World in World of Warcraft

---
## Content

Here's how we would create an addon that only outputs "Hello, World!" to the chat when the player logs into the game.

- Create a new folder in your WoW addons directory with the name "HelloWorld".
- Inside that folder, create a new file called "HelloWorld.lua".
- Now create another file in the same HelloWorld directory called HelloWorld.toc
