---
author: Stefan-Stojanovic
category: must-know
type: normal


---

# Hello World in World of Warcraft III

---
## Content

You **can set anything you want for the title, notes and author**, but its **best to set** the actual title, a note about what the addon does and who made it.

It will return only the interface value which we will use in our `.toc` file.

As for the name at the end of the file (`HelloWorld.lua`), it should be the same as your `.lua` file.

Let's fill in the `.lua` file next