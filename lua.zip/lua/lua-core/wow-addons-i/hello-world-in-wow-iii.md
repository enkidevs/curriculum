---
author: Stefan-Stojanovic
category: must-know
type: normal


---

# Hello World in World of Warcraft

---
## Content

Each game version requires a different `interface` value that you can find by lauching the game and typing this command in chat:

```lua
/run print((select(4, GetBuildInfo())))
```
