name: WoW Addons II

description: Learn how to create simple addons in WoW to enhance your experience.

aspects:
  - introduction
  - workout

learnType: GROKKING

insights:
  - hello-world-in-wow-lua-code-i
  - hello-world-in-wow-lua-code-ii
  - exp-addon-wow-i
  - exp-addon-wow-ii
  - exp-addon-wow-iii