name: WoW Addons

description: Learn how to create simple addons in WoW to enhance your experience.

aspects:
  - introduction
  - workout

learnType: GROKKING

insights:
  - lua-in-games
  - before-making-an-addon-in-wow-in-lua
  - hello-world-in-wow
  - hello-world-in-wow-ii
  - exp-addon-wow