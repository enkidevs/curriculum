name: Roblox Studio

description: Learn about how to use Roblox Studio and combine it with Lua script!

core: false

sections: 
    '0':
    - understanding-studio
    - basic-modelling
    - intro-to-scripting-i
    - intro-to-scripting-ii
    - properties-i
    - properties-ii
    - vector3
    - cframes
    - properties-iii
    - tweening-service-i
    - tweening-service-ii
    - tweening-service-applications
    - events-in-studio
    - events-application
    - building-obstacles-i
    - building-obstacles-ii
