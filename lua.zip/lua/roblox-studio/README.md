name: Roblox Studio

description: Learn about how to use Roblox Studio and combine it with Lua script!

core: false

sections: 
    '0':
    - understanding-studio-i
    - understanding-studio-ii
    - understanding-studio-iii
    - basic-modelling-i
    - basic-modelling-ii
    - intro-to-scripting-i
    - intro-to-scripting-ii
    - properties-i
    - properties-ii
    - properties-iii
    - vector3-i
    - vector3-ii
    - cframes-i
    - cframes-ii
    - properties-iv
    - tweening-service-i
    - tweening-service-ii
    - tweening-service-applications-i
    - tweening-service-applications-ii
    - events-in-studio
    - events-application
    - building-obstacles-i
    - building-obstacles-ii
