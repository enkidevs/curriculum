name: Basic Modelling

description: Learn the basics of modelling!

aspects:
- introduction

insights:
- adding-objects
- moving-objects
- scaling-objects
- rotating-objects
- useful-properties
- external-tools

