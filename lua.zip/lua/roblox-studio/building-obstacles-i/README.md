name: Building Obstacles I

description: Use this course's content to build simple obstacles!

aspects:
- workout

insights:
- obby-introduction
- platforming-i
- platforming-ii
- platforming-iii
- other-ideas