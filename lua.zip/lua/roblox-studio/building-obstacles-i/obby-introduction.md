---
author: junoocha
type: normal
category: discussion

---

# What is an Obby?
---

## Content

At this point, you should be able to **build a simple obstacle course using the skills taught in this introductory course**. However, throwing you straight into the water without any experience would lead to trouble. 

In the next few insights, we'll be going over the main ideas of obbys and hope to inspire some innovative obstacles!

> 💬 Comment below an original type of obstacle that you would make in Roblox!
