name: CFrame Basics I

description: Learn the basics of CFrame!

aspects:
- workout

insights:
- cframes-intro
- cframes-syntax-i
- cframes-syntax-ii


