name: CFrame Basics

description: Learn the basics of CFrame!

aspects:
- workout

insights:
- cframes-intro
- cframes-syntax-i
- cframes-syntax-ii
- cframes-math
- cframes-application-i
- cframes-application-ii

