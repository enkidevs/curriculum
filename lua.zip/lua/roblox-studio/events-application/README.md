name: Using Events in Roblox Studio

description: Learn how to make a kill block using events in Roblox Studio!

aspects:
- workout

insights:
- events-application-i
- events-application-ii
- events-application-iii