name: Events in Roblox Studio

description: Learn about using events in roblox studio!

aspects:
- workout

insights:
- events-in-studio
- built-in-events
- events-syntax
