name: Intro to Scripting on Studio I

description: Learn the basics of scripting!

aspects:
- workout

insights:
- adding-a-script
- the-print-output
- accessing-instances-with-variables-i
- accessing-instances-with-variables-ii
- accessing-instances-with-variables-iii

