---
author: junoocha
type: normal
category: must-know

---

# Adding a Script

---

## Content

Let’s finally add a script to our game! Hover over the **ServerScriptService** in the **Explorer Tab** and click on the *plus sign*. In the dropdown menu, press on **"Script"**. We will be using Lua, as it's Roblox's main language.

![adding-a-script](https://img.enkipro.com/ed480bae4066eba0f5e620e76e76d2c6.gif)

In the new script file, you will notice the line:

```lua
print("Hello World")
```
Let’s run the game and see what happens.

> Move on to the next insight after running the game

---