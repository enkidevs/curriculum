name: Intro to Scripting on Studio II

description: Learn more on the basics of scripting!

aspects:
- workout

insights:
- functions-in-studio
- built-in-methods
- wait-command
- adding-instances-using-scripts-i
- adding-instances-using-scripts-ii

