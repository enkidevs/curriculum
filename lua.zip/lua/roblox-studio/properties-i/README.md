name: Properties I

description: Learn how to adjust properties through code!

aspects:
- workout

insights:
- intro-to-scripting-properties
- how-to-change-property
- brick-color-i
- brick-color-ii