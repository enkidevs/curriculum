name: Properties I

description: Learn how to adjust properties through code!

aspects:
- workout

insights:
- intro-to-scripting-properties
- appearance-property-i
- appearance-property-ii
- appearance-property-iii
- appearance-property-iiii