name: Properties III

description: Learn more on adjusting properties through code!

aspects:
- workout

insights:
- collision-i
- collision-ii
- data-i
- data-ii
- data-iii

