name: Properties IV

description: Learn more on adjusting properties through code!

aspects:
- workout

insights:
- transform-i
- transform-ii
- transform-iii
- pivot-i
- pivot-ii

