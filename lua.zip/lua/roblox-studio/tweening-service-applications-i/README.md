name: TweenService Applications I

description: Learn how to create animations with TweenService!

aspects:
- workout

insights:
- setting-up-tween
- color
- transparency-and-reflection
- transform


