name: TweenService Applications

description: Learn how to create animations with TweenService!

aspects:
- workout

insights:
- setting-up-tween
- color
- transparency-and-reflection
- transform
- multiple-tweens
- example

