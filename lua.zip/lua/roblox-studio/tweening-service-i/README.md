name: TweeningService I

description: Learn how to use TweenService in Roblox Studio!

aspects:
- workout

insights:
- tween-service-intro
- tween-service-syntax
- property-table-variable
- info-variable


