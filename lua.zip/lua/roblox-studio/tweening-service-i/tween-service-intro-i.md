---
author: junoocha
type: normal
category: discussion

---

# Alternatives to Loops?
---

## Content
For the last few workouts, there was an emphasis on properties. You may have started thinking about how scripting can change properties while the game is running.  

One way to create dynamic effects is by using loops! However, you may have also realized that using **loops can make changes very choppy**. So what alternatives are there?

---
