name: TweeningService II

description: Learn about the specific variables used in TweenInfo!

aspects:
- workout

insights:
- time-and-repeat-count
- reverses-and-delay-time
- easing-style
- easing-direction


