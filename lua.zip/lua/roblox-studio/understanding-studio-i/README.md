name: Roblox Studio Introduction

description: An Intro to Roblox Studio

aspects:
- introduction

insights:
- intro-to-studio-i
- intro-to-studio-ii
- intro-to-studio-iii


