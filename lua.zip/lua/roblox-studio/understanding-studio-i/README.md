name: Understanding Roblox Studio

description: Learn about the basics of roblox studio!

aspects:
- introduction
- workout

insights:
- intro-to-studio
- studio-interface
- explorer-interface-i
- explorer-interface-ii


