---
author: junoocha
type: normal
category: discussion


---

# Welcome To Roblox Studio

---

## Content

Roblox, the hub of imagination, where you can create anything you wish. Fantasy games to go on explorations, a restaurant simulator where you can manage and create your own restaurant, or even a place to hang out. The power to create your vision and even profit from it is within your hands! 

You excitedly hop onto Roblox Studio[1] to create the game of your dreams and… oh. How do I start? 

---

## Footnotes

[1: Roblox Studio]

Roblox Studio is the application where you’re able to create your own game. This is a separate application from the Roblox app.
