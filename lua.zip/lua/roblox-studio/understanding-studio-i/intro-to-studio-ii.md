---
author: junoocha
type: normal
category: discussion
links:
  - >-
    [Setting Up Roblox Studio](https://create.roblox.com/docs/studio/setting-up-roblox-studio){website}

---

# What to Expect

---

## Content

Throughout this course, we will walk you through how Roblox Studio works and how you can start coding and building your own Roblox game. 

By the end of this course, you should be able to create a simple obstacle course, AKA obbys[1] on Roblox using the content taught through our course!

> While going through this course, it's highly recommended to have completed the introductory Lua course, as well as having the Roblox Studio app open to follow along!

---

## Footnotes

[1: Obbys]

Obbys are short for Obstacle Courses, and are commonly used on the Roblox platform.
