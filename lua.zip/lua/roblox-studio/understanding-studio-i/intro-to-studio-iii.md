---
author: junoocha
type: normal
category: discussion


---

# An Introduction to Roblox Studio

---

## Content

Many players have their own aspirations as to why they want to build, whether it is a hobby or a job. While it's not mandatory, having ambitions can help with the process!

💬 What made you want to learn in the first place? 

> Comment below or have a look at other comments to see why people started scripting in Roblox.

---
