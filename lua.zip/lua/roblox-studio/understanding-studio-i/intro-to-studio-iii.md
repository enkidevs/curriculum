---
author: junoocha
type: normal
category: discussion


---

# An Introduction to Roblox Studio

---

## Content

Many players have their own aspirations as to why they want to build, whether it was a hobby or as a job.

💬 What made you want to learn in the first place? 

> Comment below or have a look at other comments to see why people started scripting in Roblox.

---
