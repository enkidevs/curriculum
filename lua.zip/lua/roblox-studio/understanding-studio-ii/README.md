name: Roblox Studio Interface

description: Learn about the basics of roblox studio!

aspects:
- introduction
- workout

insights:
- studio-interface
- explorer-interface-i
- explorer-interface-ii


