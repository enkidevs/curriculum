name: I/O Operations II

description: Learn about how to open and close files, along with other useful commands.

aspects:
  - introduction
  - workout

learnType: GROKKING

insights:
  - io-lines-in-lua
  - io-open-in-lua-i
  - io-open-in-lua-ii
  - io-input-output-in-lua