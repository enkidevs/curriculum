name: Loops Introduction

description: Learn about what loops are in Lua.

aspects:
  - introduction

learnType: GROKKING

insights:
  - what-are-loops-in-lua
  - types-of-loops
  - for-loops-in-lua-i
  - for-loops-in-lua-ii