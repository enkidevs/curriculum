name: Array Basics 
description: Learn how to work with multi-dimensional arrays
and understand array shapes.

insights:
  - python-numpy-array-dimensions
  - python-numpy-array-reshaping
  - python-numpy-array-stacking
  - python-numpy-array-splitting
  - python-numpy-array-copying

aspects:
  - introduction
  - workout
