name: Array Manipulation Exercise
description: Practice manipulating arrays by
organizing data for a small game.

insights:
  - python-numpy-array-manipulation-practice

aspects:
  - workout
  - deep
