name: Array Manipulation
description: Learn different ways to manipulate and transform NumPy arrays.

insights:
  - python-numpy-array-joining
  - python-numpy-array-splitting
  - python-numpy-array-adding
  - python-numpy-array-inserting
  - python-numpy-array-deleting

aspects:
  - introduction
  - workout 