name: Array Math 
description: Learn how to perform mathematical operations and
functions on NumPy arrays.

insights:
  - python-numpy-basic-math
  - python-numpy-advanced-math
  - python-numpy-trigonometry
  - python-numpy-rounding
  - python-numpy-random

aspects:
  - introduction
  - workout
