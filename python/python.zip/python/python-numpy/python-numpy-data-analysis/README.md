name: Data Analysis
description: Learn how to analyze and process real-world data using NumPy.

insights:
  - python-numpy-data-loading
  - python-numpy-data-cleaning
  - python-numpy-data-aggregation
  - python-numpy-data-grouping
  - python-numpy-data-visualization

aspects:
  - introduction
  - workout 