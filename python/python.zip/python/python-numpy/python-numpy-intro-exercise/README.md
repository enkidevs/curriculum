name: NumPy Intro Exercise
description: Practice creating and manipulating NumPy
arrays.

insights:
  - python-numpy-intro-practice

aspects:
  - workout
  - deep
