name: Scientific Computing Exercise
description: Practice using NumPy for scientific calculations in a physics simulation.

insights:
  - python-numpy-scientific-practice

aspects:
  - workout
  - deep 