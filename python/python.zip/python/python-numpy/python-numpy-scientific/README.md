name: Scientific Computing
description: Learn how to use NumPy for scientific calculations and simulations.

insights:
  - python-numpy-scientific-basics
  - python-numpy-scientific-functions
  - python-numpy-scientific-constants
  - python-numpy-scientific-random
  - python-numpy-scientific-stats

aspects:
  - introduction
  - workout 