name: Signal Processing Exercise
description: Practice analyzing and manipulating time-series data in a real-world scenario.

insights:
  - python-numpy-signal-processing-practice

aspects:
  - workout
  - deep 