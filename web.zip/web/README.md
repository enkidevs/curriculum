name: Web

description: Create your first webpage here. Includes HTML, CSS, and more.

color: C3A6FF

icon: https://img.enkipro.com/6af370046a3f7c19ba2f16336be2a85f.png

language: css

availableAspects:
  - introduction
  - workout
  - deep
  - obscura

startingPoints:
  - title: Advanced CSS
    subtitle: Flexbox, Responsive Design, Animations
    icon: 🎨
    workout: intro-css
