name: Citation Elements
type: insights-list
description: Check out these semantic elements for specific data
insights:
  - intro-cite
  - intro-q
  - blockquotes
  - address
  - intro-bdo
  - intro-bdi
exercise:
  - html-citation-elements-codepen-exercise
  - html-quotation-elements-codepen-exercise
aspects:
  - introduction
  - workout
  - deep
  - obscura
 
