name: Computer Code

type: insights-list

description: Displaying code in your HTML website.

section: 0

insights:
  - intro-code
  - intro-kbd
  - intro-samp
  - intro-pre
  - intro-var
  - html-computer-code-codepen-exercise

aspects:
  - introduction
  - workout
  - deep
