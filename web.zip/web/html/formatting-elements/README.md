name: Formatting HTML Elements
description: How to format other HTML elements.
insights:
  - intro-span
  - intro-hr
  - button
  - button-attributes
  - formatting-elements-codepen-exercise
  - html-create-buttons-codepen-exercise

aspects:
  - introduction
  - workout
 
