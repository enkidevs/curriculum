name: Formatting Text Elements II
description: More text formatting elements.
insights:
  - intro-abbr
  - intro-dfn
  - small
  - intro-time
  - intro-wbr
  - html-dfn-abbr-codepen-exercise
  - html-multi-element-3-codepen-exercise
aspects:
  - introduction
 
