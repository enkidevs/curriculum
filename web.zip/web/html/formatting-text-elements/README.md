name: Formatting Text Elements I
description: How to format text with HTML.
insights:
  - intro-br
  - emphasis-i-and-em
  - important-b-and-strong
  - sub-and-superscript-sub-and-sup
  - editing-s-del-ins
  - editing-u-mark
  - html-s-del-ins-codepen-exercise
  - html-b-strong-codepen-exercise
  - html-multi-element-1-codepen-exercise
  - html-multi-element-2-codepen-exercise
  - html-sup-sub-codepen-exercise
  - html-u-mark-codepen-exercise
aspects:
  - introduction
 
