name: Advanced Text Input
type: insights-list
description: 'With attributes on the Input element, we can do a lot!'
insights:
  - placeholder
  - range
  - intro-step
  - min-and-max
  - type-password
  - pattern-regexp

  - html-create-password-pattern-codepen-exercise
  - html-create-new-account-codepen-exercise
  - html-create-account-codepen-exercise
aspects:
  - introduction
  - workout
  - deep
 
