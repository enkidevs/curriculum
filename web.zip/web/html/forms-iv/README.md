name: Advanced Button Attributes
type: insights-list
description: 'Using button attributes, we can do a lot!'
insights:
  - image-button
  - formaction
  - formenctype-and-enctype
  - formmethod
  - formnovalidate-and-novalidate
  - formtarget

  - html-image-button-codepen-exercise
aspects:
  - workout
  - deep
  - obscura
  - introduction
 
