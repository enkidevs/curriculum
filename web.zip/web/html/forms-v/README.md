name: Interface Form Attributes
type: insights-list
description: There are lots of attributes that improve the user experience!
insights:
  - autocomplete
  - autofocus
  - multiple
  - oninput
  - output

  - html-form-attributes-exercise
aspects:
  - introduction
  - workout
  - deep
 
