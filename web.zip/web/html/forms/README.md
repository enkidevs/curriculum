name: Forms
type: insights-list
description: Collect input with HTML forms!
insights:
  - intro-form
  - input-element
  - text-field
  - text-area
  - submit-and-reset
  - html-input-types-codepen-exercise
  - html-buttons-text-area-codepen-exercise

aspects:
  - introduction
  - workout
 
