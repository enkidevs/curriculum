---
author: Stefan-Stojanovic
type: normal
category: must-know
links:
  - >-
    [HTML <textarea>
    Element](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/textarea){documentation}
practiceQuestion:
  formats:
    - fill-in-the-gap
    - type-in-the-gap
  context: standalone
revisionQuestion:
  formats:
    - fill-in-the-gap
  context: standalone
---

# Text Area


---

## Content

The HTML `<textarea>` element is used to represent a multi-line input text area.

Simple example:

```html
<textarea
  name="textbox">
</textarea>
```

![simple-textarea](https://img.enkipro.com/37719384b3886ac680cbe2923df84598.png)
The `<textarea>` element has many attributes. Some of the more common are:

- `autocomplete` enables autocomplete for `textarea`
- `autofocus` sets focus on `textarea` upon page load
- `cols`
- `maxlength`
- `minlength`
- `readonly`
- `placeholder`
- `rows`

Example with attributes:

```html
<textarea
   name="textarea" rows="10"
   cols="30"
   placeholder="Enter text here">
</textarea>
```

![simple-textarea-attributes](https://img.enkipro.com/220982fbfdc4e10a71c73e9dd998b001.png)
In the example above, `rows="10"` specifies the number of visible text lines for the control,  `cols="30"` specifies the average characters width and the `placeholder` attribute presents a hint which disappears after the user types something and reappears if there is no input.


---

## Practice

Write the form code that creates a multi-line input for text named `textbox`.

```html
<???
  ???="???">
<???>
```

- textarea
- name
- textbox
- /textarea
- form
- input
- /input


---

## Revision

Which element creates a multi-line input field that is 10 lines of text in height and 50 average characters in width.

???

- `<textarea name="message" rows="10" cols="50"></textarea>`
- `<textarea name="message" rows="30" cols="10"></textarea>`
- `<input type="textarea" name="message" rows="10" cols="30">`
- `<input name="message" rows="10" cols="30"></input>`


---

## Quiz

### How much do you know about text fields?


In this code, how are rows and columns measured?

`<textarea name="message" rows="20" cols="50"></textarea>`

Rows: ???
Columns: ???

- Lines of Text
- Average character width
- able Column
- Table Row
- Unicode code points
- Number of characters
