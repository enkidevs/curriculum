name: Global Attributes
description: List and explanations of HTMLs shared global attributes.
insights:
  - intro-global-attributes
  - global-attributes-2
  - global-attributes-3

  - html-class-codepen-exercise
  - html-id-codepen-exercise
  - html-style-codepen-exercise
  - html-title-codepen-exercise
  - html-multi-global-attribute-exercise
aspects:
  - introduction
  - workout
  - deep
 
