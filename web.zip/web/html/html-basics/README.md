name: HTML Basics
description: The building blocks of webpages.
insights:
  - hypertext-markup-language
  - headings-and-paragraphs
  - hyperlinks
  - images
  - divisions-and-spans
aspects:
  - introduction
 
