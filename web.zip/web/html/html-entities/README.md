name: HTML Entities
type: insights-list
description: How to display some reserved characters.
section: 0
insights:
  - non-breaking-space
  - greater-and-less-than
  - copyright
  - ampersand
exercise:
  - html-entity-codepen-exercise
aspects:
  - introduction
  - workout
  - deep
 
