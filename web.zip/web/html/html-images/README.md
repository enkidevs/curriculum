name: Advanced Images
description: Advanced image attributes help you make advanced images
insights:
  - image-types
  - image-alt
  - image-title
  - image-height-width
  - image-map
  - image-base

  - html-image-1-codepen-exercise
  - html-image-2-codepen-exercise
  - html-image-3-codepen-exercise
  - html-image-map-codepen-exercise
aspects:
  - introduction
  - workout
  - obscura
 
