name: HTML Structure

type: insights-list

description: How to write HTML code.

section: 0

insights:
  - html-structure-define
  - elements
  - html-tags
  - attributes
  - comments

  - html-comment-codepen-exercise
  - html-element-attribute-codepen-exercise

aspects:
  - introduction
