name: HTML Versions
type: insights-list
description: Distinguish between versions of HTML
insights:
  - html4-xhtml-and-html5
  - html4-xhtml-and-html5-continued
aspects:
  - introduction
  - workout
  - deep
 
