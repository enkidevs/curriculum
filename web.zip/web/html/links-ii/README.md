name: Links II
description: 'Mail, image, and download links.'
insights:
  - image-link
  - image-mailto
  - link-download
aspects:
  - introduction
 
