name: Links
description: How to link to other documents.
insights:
  - anchor-links
  - link-relative-paths
  - link-absolute-paths
  - link-target
aspects:
  - introduction
 
