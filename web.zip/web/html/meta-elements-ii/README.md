name: Meta Elements II
type: insights-list
description: More attributes for <meta>.
section: 0
insights:
  - author
  - http-equiv
  - robots
aspects:
  - introduction
  - workout
  - obscura
  - deep
 
