name: Meta Elements
type: insights-list
description: What's <meta> and its benefits.
section: 0
insights:
  - meta-intro
  - charset
  - description
  - keywords
aspects:
  - introduction
  - workout
 
