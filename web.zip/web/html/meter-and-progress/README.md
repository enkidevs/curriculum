name: Meter & Progress
description: Elements used to indicate completion.
insights:
  - meter
  - meter-attributes
  - meter-attributes-ii
  - progress

  - html-create-meter-codepen-exercise
  - html-create-progress-bar-codepen-exercise
aspects:
  - deep
  - workout
 
