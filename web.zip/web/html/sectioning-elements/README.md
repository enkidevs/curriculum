name: Sectioning Elements
type: insights-list
description: Divide your content up with these elements
insights:
  - div
  - header
  - main
  - nav
  - footer

  - html-sectioning-elements-1-codepen-exercise
  - html-sectioning-elements-2-codepen-exercise
  - html-sectioning-elements-3-codepen-exercise
  - html-sectioning-elements-4-codepen-exercise
aspects:
  - introduction
  - workout
  - deep
 
