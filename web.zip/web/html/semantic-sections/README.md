name: Semantic Sections
type: insights-list
description: Specify what content is on your page with semantic sections
insights:
  - semantic-containers
  - section
  - article
  - aside
  - figure-and-figcaption

  - html-semantics-1-codepen-exercise
  - html-semantics-2-codepen-exercise
  - html-semantics-3-codepen-exercise
aspects:
  - introduction
  - workout
  - deep
 
