name: Tables
description: Adding tabular data to HTML
insights:
  - table-tr-and-td
  - intro-th
  - caption
  - colgroup-and-col
  - thead-tbody-and-tfoot
  - html-table-1-codepen-exercise
  - html-table-2-codepen-exercise
  - html-table-3-codepen-exercise
  - html-table-4-codepen-exercise
game: table-it
aspects:
  - introduction
  - workout
  - deep
 
