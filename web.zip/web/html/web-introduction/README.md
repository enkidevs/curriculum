name: Web Introduction
type: insights-list
description: How does the web work?
insights:
  - html-css-intro
  - html-defined
  - css-defined
  - html-css-code
  - html-css-browser
aspects:
  - introduction
 
