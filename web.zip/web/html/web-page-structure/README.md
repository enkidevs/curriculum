name: Web Page Structure

type: insights-list

description: Learn how an HTML webpage is structured.

section: 0

insights:
  - doctype
  - html-element
  - head-element
  - optional-elements

aspects:
  - introduction
