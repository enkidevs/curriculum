---
author: Stefan-Stojanovic
type: normal
category: must-know
links:
  - >-
    [HTML <html>
    Element](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/html){documentation}
practiceQuestion:
  formats:
    - fill-in-the-gap
  context: standalone
revisionQuestion:
  formats:
    - fill-in-the-gap
  context: standalone
---

# The html Element


---

## Content

The HTML `<html>` element is the root (top-level element) of an HTML document and is the primary container for all of the other elements in the documents, which are the descendants of this one element.

Within every `<html>` element are two primary elements:

- `<head>`: Data useful for the page.
- `<body>`: The content of the page itself.

Example:

```html
<!DOCTYPE html>
<html lang="en-GB">
  <head>...</head>
  <body>...</body>
</html>
```

The `lang` attribute is useful for helping both search engines and screen readers determine the proper language of the text on the page. When the `lang` attribute is not included, screen readers will use the operating system's set language, which isn't always the best because it may not provide the proper accents and pronunciation.

The `<html>` element is easily modifiable with CSS by using either the `html` or the `:root` selector. The selectors are identical, except that the `:root` selector's specificity is higher (meaning it will override `html`).

For instance, by adding the CSS:

```css
:root {
    background: #ff0000;
}
html {
    background: #0000ff;
}

```
we change the background color of the `:root` to red, and even though the `html` has been set to blue, the `:root` style overrides it.


---

## Practice

What is meant by the html element being the root of an HTML page?

???

- It's the single HTML element that contains every other HTML element.
- It is the deepest node of a tree of HTML nodes.
- It represents every HTML attribute specified.
- It provides a simple fix to the issues of the browser wars of the 1990s.


---

## Revision

What is the root element of an HTML document?

```html
???
```

What HTML element is best to assign the document’s primary language?

```html
<??? lang="en-GB">
```

- `<html>`
- `html`
- `<head>`
- `<body>`
- `<root>`
- `tree`
- `head`
- `body`


---

## Quiz

### How much do you know about using CSS with HTML?


Using a `:root` selector in CSS will target which HTML element?

???

- `<html>`
- `<body>`
- `<head>`
- `<main>`
- `<root>`
- every HTML element
