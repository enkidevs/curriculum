name: Animations
description: Go though how animations are made in using CSS.
insights:
  - animation-basics-in-css
  - chaining-animations
  - using-animation-delay-in-debugging
  - shorthand-transitions
  - prepare-for-will-change
aspects:
  - workout
  - deep
