name: The Box Model
description: 'Padding, margin, border'
insights:
  - the-box-model
  - borders
  - margin-and-padding
  - the-box-sizing-property
  - the-display-property
  - box-model-discussion-insight
  
aspects:
  - introduction
  - workout
  - deep
 
