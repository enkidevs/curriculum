name: Centring Recipes
description: Different techniques to centre elements.
insights:
  - horizontal-centering-fluid-blocks
  - horizontal-centering-with-margin-0-auto
  - vertical-centering-fluid-blocks
  - vertical-centering-with-margin-top
  - vertically-center-text
  - vertically-center-anything
aspects:
  - workout
  - deep
  - introduction
