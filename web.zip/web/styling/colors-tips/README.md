name: Colors Tips
description: Working with colors.
insights:
  - hexadecimal-color-system
  - determine-the-opacity-of-background-colors-using-the-rgba-declaration
  - currentcolor-improves-code-reusability
  - matching-images-to-a-website-s-color-scheme
  - >-
    default-to-a-transparent-border-color-before-adding-a-border-to-on-hover-state-elements
aspects:
  - introduction
  - workout
  - deep
 
