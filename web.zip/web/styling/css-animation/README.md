name: CSS Animation

description: Creating and manipulating shapes with CSS.

insights:
  - making-shapes-with-transform
  - pause-and-play-css-animations
  - manipulating-shapes-using-css-border
  - manipulating-shapes-using-css-clip-path
  - manipulating-shapes-using-css-shape-outside
  - animations-in-webkit-browsers

aspects:
  - workout
  - deep
