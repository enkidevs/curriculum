name: CSS Basics
description: How CSS works
insights:
  - applying-css
  - internal-css
  - css-specificity
  - css-specificity-ii
  - common-css-properties-values
  - relative-css-properties
game: will-this-work-on-ie8
aspects:
  - introduction
  - workout
  - deep
 
