name: Recipes
description: Solutions to real world scenarios.
insights:
  - load-custom-fonts-on-a-web-page-using-font-face
  - disclose-file-format-of-links
  - fixed-navigation-bar
  - hide-the-scrollbar-in-webkit-browser
  - autohiding-scrollbars-for-ie
aspects:
  - workout
  - deep
 
