name: Dimensions & Box Sizing
description: Dimensioning 101
insights:
  - vh-and-vw-vmin-and-vmax
  - use-em-instead-of-px-for-sizes
  - vertical-percentages-are-relative-to-container-width-not-height
  - use-box-sizing-to-define-an-element-s-width-and-height-properties
  - inherit-box-sizing
aspects:
  - workout
  - deep
  - introduction
 
