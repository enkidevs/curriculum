name: Flexbox
description: A must for responsive design
insights:
  - flexbox-flex-wrap
  - flexbox-justify-content
  - flexbox-order
  - using-flex-grow
  - using-flex-shrink
  - avoid-margin-hacks-with-flexbox
aspects:
  - workout
  - deep
  - introduction
 
