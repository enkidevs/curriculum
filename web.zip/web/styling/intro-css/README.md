name: Introduction to CSS
description: Introduction to how to style the web.
insights:
  - what-is-css
  - css-declaration
  - what-is-cascading
  - basic-selectors
  - class-and-id-selectors
aspects:
  - introduction
  - deep
 
