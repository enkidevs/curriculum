name: Positioning Tips
description: Ins and outs of positioning.
insights:
  - clearfix-for-layouts
  - position-elements-with-position-sticky
  - controlling-cellpadding-and-cellspacing-in-css
  - direction-column-reverse
  - equal-width-table-cells
aspects:
  - introduction
  - workout
  - deep
 
