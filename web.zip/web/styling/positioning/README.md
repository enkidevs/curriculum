name: Positioning
description: Explore how to position HTML elements.
insights:
  - block-elements-characteristics
  - inline-elements-characteristics
  - inline-block-elements-characteristics
  - positioning-elements
  - floating-elements
aspects:
  - introduction
  - deep
 
