name: Practical CSS
description: Tips to use in practice
insights:
  - debug-with-the-selector
  - add-line-height-to-body
  - difference-between-initial-and-inherit
  - the-difference-between-display-none-and-visibility-hidden
  - page-breaks-for-printing
game: c-s-splat
aspects:
  - introduction
  - workout
  - deep
 
