name: Pseudo Classes I
description: Special states of elements.
insights:
  - use-pseudo-classes-to-describe-a-special-state-of-an-element
  - the-hover-pseudo-class
  - use-not-to-apply-unapply-styles
  - the-nth-child-property
  - required-and-optional-pseudo-classes
aspects:
  - workout
  - deep
  - introduction
 
