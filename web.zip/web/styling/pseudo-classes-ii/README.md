name: Pseudo Classes II
description: Special states of elements.
insights:
  - drag-and-drop-pseudo-class-drop
  - matches-any-pseudo-class-matches
  - highlight-input-forms-using-focus-pseudo-class
  - empty-and-blank
  - in-range-and-out-of-range
aspects:
  - workout
  - deep
  - introduction
 
