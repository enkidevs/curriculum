name: Pseudo Elements
description: Special types of elements.
insights:
  - use-pseudo-elements-to-style-specific-parts-of-an-element
  - styling-elements-using-before-and-after
  - drop-caps-with-first-letter
  - use-attribute-selectors-with-empty-links
  - change-selected-area-color
aspects:
  - introduction
  - workout
  - deep
 
