name: Sass I
description: Syntactically Awesome StyleSheets
insights:
  - what-is-sass
  - rules-and-directives
  - partials
  - importer
  - sass-supported-comments
aspects:
  - introduction
  - deep
  - workout
 
