name: Sass II
description: Syntactically Awesome StyleSheets
insights:
  - referencing-parent-selectors
  - sass-mixins
  - using-sassscripts-interactive-shell
  - sass-extend-inheritance
  - strings-in-sassscript
aspects:
  - workout
  - deep
  - introduction
 
