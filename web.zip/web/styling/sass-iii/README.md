name: Sass III
description: Operations in Syntactically Awesome StyleSheets
insights:
  - sass-operators
  - sassscript-number-functions
  - sassscript-color-operations
  - sassscript-string-operations
  - sassscript-map-and-list-functions
aspects:
  - workout
  - deep
  - introduction
 
