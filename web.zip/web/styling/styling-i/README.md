name: Styling I
description: Styling recipes.
insights:
  - change-the-style-of-borders-using-border-style
  - use-border-radius-to-style-rounded-corners-of-an-element
  - use-list-style-type-to-change-the-marker-type-in-lists
  - removing-the-bullets-from-the-ul
  - comma-separated-lists
aspects:
  - introduction
  - deep
  - workout
 
