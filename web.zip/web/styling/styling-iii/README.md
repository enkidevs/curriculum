name: Styling III
description: Styling recipes.
insights:
  - border-radius-circle
  - border-radius-property-can-use-slash-syntax
  - declaring-linear-gradients-using-the-background-property
  - use-the-box-shadow-property-to-create-shadow-effects-on-an-element
  - multiple-borders-with-pseudo-elements
aspects:
  - workout
  - deep
 
