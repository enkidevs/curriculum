name: Typography how-to's
description: Employ CSS features to work on the typography of pages.
insights:
  - a-great-font-resource-google-font-api
  - letter-spacing-property
  - change-the-color-of-the-decoration-with-text-decoration-color
  - change-the-style-of-the-decoration-with-text-decoration-style
  - using-the-font-variant-property-to-transform-text-to-small-caps
game: existential-crisis
aspects:
  - introduction
  - deep
  - workout
 
